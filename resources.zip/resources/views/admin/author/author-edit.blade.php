@extends('admin.layouts.app')

@section('title', 'Edit Author')

@section('content')
<div class="container-xxl">

    <!-- Header -->
    <div class="row align-items-center mb-4">
        <div class="col">
            <h3 class="fw-bold mb-0">Edit Author</h3>
        </div>

        <div class="col-auto">
            <a href="{{ route('author.index') }}" class="btn btn-secondary">
                <i class="icofont-arrow-left me-1"></i> Back
            </a>
        </div>
    </div>

    <!-- Form Card -->
    <div class="card">
        <div class="card-body">

            <form action="{{ route('author.update', $data->id) }}"
                  method="POST"
                  enctype="multipart/form-data">

                @csrf

                <div class="row">

                    <!-- Name -->
                    <div class="col-md-6 mb-3">
                        <label for="name" class="form-label">
                            Name <span class="text-danger">*</span>
                        </label>

                        <input type="text"
                               name="name"
                               id="name"
                               class="form-control @error('name') is-invalid @enderror"
                               value="{{ old('name', $data->name) }}"
                               placeholder="Enter Author Name">

                        @error('name')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Designation -->
                    <div class="col-md-6 mb-3">
                        <label for="designation" class="form-label">
                            Designation
                        </label>

                        <input type="text"
                               name="designation"
                               id="designation"
                               class="form-control @error('designation') is-invalid @enderror"
                               value="{{ old('designation', $data->designation) }}"
                               placeholder="Enter Designation">

                        @error('designation')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Years of Experience -->
                    <div class="col-md-6 mb-3">
                        <label for="years_of_experience" class="form-label">Years of Experience</label>

                        <input type="text"
                            name="years_of_experience"
                            id="years_of_experience"
                            class="form-control @error('years_of_experience') is-invalid @enderror"
                            value="{{ old('years_of_experience', $data->years_of_experience) }}"
                            placeholder="e.g. 18 Years of Experience">

                        @error('years_of_experience')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Social Media -->
                    <div class="col-md-4 mb-3">
                        <label for="social_media_name" class="form-label">Social Media Name</label>

                        <input type="text"
                            name="social_media_name"
                            id="social_media_name"
                            class="form-control @error('social_media_name') is-invalid @enderror"
                            value="{{ old('social_media_name', $data->social_media_name) }}"
                            placeholder="e.g. LinkedIn">

                        @error('social_media_name')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="col-md-4 mb-3">
                        <label for="social_media" class="form-label">Social Media URL</label>

                        <input type="text"
                            name="social_media"
                            id="social_media"
                            class="form-control @error('social_media') is-invalid @enderror"
                            value="{{ old('social_media', $data->social_media) }}"
                            placeholder="https://www.linkedin.com/...">

                        @error('social_media')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="col-md-4 mb-3">
                        <label for="social_media_image" class="form-label">Social Media Image</label>

                        @if($data->social_media_image)
                            <div class="mb-2">
                                <img src="{{ asset('public/Authors/social_media_image/'.$data->social_media_image) }}"
                                    class="img-thumbnail"
                                    style="width:100px;height:100px;object-fit:cover;">
                            </div>
                        @endif

                        <input type="file"
                            name="social_media_image"
                            id="social_media_image"
                            class="form-control @error('social_media_image') is-invalid @enderror"
                            accept="image/*">

                        @error('social_media_image')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Description -->
                    <div class="col-md-12 mb-3">
                        <label for="description" class="form-label">Description</label>

                        <textarea name="description"
                                id="description"
                                rows="8"
                                class="form-control @error('description') is-invalid @enderror">{{ old('description', $data->description) }}</textarea>

                        @error('description')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Meta Title -->
                    <div class="col-md-6 mb-3">
                        <label for="meta_title" class="form-label">
                            Meta Title
                        </label>

                        <input type="text"
                            name="meta_title"
                            id="meta_title"
                            class="form-control @error('meta_title') is-invalid @enderror"
                            value="{{ old('meta_title', $data->meta_title) }}"
                            placeholder="Enter Meta Title">

                        @error('meta_title')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Meta Description -->
                    <div class="col-md-6 mb-3">
                        <label for="meta_description" class="form-label">
                            Meta Description
                        </label>

                        <textarea name="meta_description"
                                id="meta_description"
                                rows="4"
                                class="form-control @error('meta_description') is-invalid @enderror"
                                placeholder="Enter Meta Description">{{ old('meta_description', $data->meta_description) }}</textarea>

                        @error('meta_description')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Main Image -->
                    <div class="col-md-4 mb-3">
                        <label for="main_image" class="form-label">
                            Main Image
                        </label>

                        @if($data->main_image)
                            <div class="mb-2">
                                <img src="{{ asset('public/Authors/main_image/'.$data->main_image) }}"
                                     class="img-thumbnail"
                                     style="width:100px;height:100px;object-fit:cover;">
                            </div>
                        @endif

                        <input type="file"
                               name="main_image"
                               id="main_image"
                               class="form-control @error('main_image') is-invalid @enderror"
                               accept="image/*">

                        @error('main_image')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Thumbnail Image -->
                    <div class="col-md-4 mb-3">
                        <label for="thumbnail_image" class="form-label">
                            Thumbnail Image
                        </label>

                        @if($data->thumbnail_image)
                            <div class="mb-2">
                                <img src="{{ asset('public/Authors/thumbnail_image/'.$data->thumbnail_image) }}"
                                     class="img-thumbnail"
                                     style="width:100px;height:100px;object-fit:cover;">
                            </div>
                        @endif

                        <input type="file"
                               name="thumbnail_image"
                               id="thumbnail_image"
                               class="form-control @error('thumbnail_image') is-invalid @enderror"
                               accept="image/*">

                        @error('thumbnail_image')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Status -->
                    <div class="col-md-6 mb-3">
                        <label for="is_active" class="form-label">
                            Status
                        </label>

                        <div class="form-check form-switch">
                            <input type="checkbox"
                                   name="is_active"
                                   id="is_active"
                                   value="1"
                                   class="form-check-input"
                                   {{ old('is_active', $data->is_active) ? 'checked' : '' }}>

                            <label class="form-check-label" for="is_active">
                                Active
                            </label>
                        </div>
                    </div>

                </div>

                <!-- Buttons -->
                <div class="mt-3">

                    <button type="submit" class="btn btn-primary">
                        <i class="icofont-save me-1"></i> Update Author
                    </button>

                    <a href="{{ route('author.index') }}"
                       class="btn btn-secondary">
                        Cancel
                    </a>

                </div>

            </form>

        </div>
    </div>

</div>
<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>

<script>
    ClassicEditor
        .create(document.querySelector('#description'))
        .catch(error => {
            console.error(error);
        });
</script>
@endsection
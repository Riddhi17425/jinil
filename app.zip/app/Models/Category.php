<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Category extends Model
{

    use HasFactory, SoftDeletes;

    protected $table = "category";

    protected $fillable = [

        'category',

        'cat_description',

        'url',

        'meta_title',

        'meta_description',

        'faqs_title',

        'faqs_desc', 

        'faqs',    

    ];

     protected $casts = [
        'faqs' => 'array',   // NEW
    ];

}

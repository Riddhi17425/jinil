@include('layouts.frontheader')

<section class="navi_page">
    <div class="container-fluid">

        <div class="navi_page_child">
            <div class="col-lg-10">
                <p class="title_24"><a href="{{ url('/') }}" class="text-585">Home</a> / Downloads</p>
                <h1 class="title_60">Technical Resources & Downloads</h1>
                <p class="mb-0">Access machine brochures, technical specifications, layout drawings, safety
                    documentation, and compliance certificates for Jinil shot blasting solutions.</p>
            </div>

            <a href="{{ route('contact') }}" class="contact_circle">

                <!-- circular text image -->
                <img src="{{ asset('public/front/images/innder-header-jump.svg') }}" class="circle_text_img" alt="innder header jump">

                <svg class="arrow_img" width="18" height="23" viewBox="0 0 18 23" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M8.85653 1.15617L8.85653 20.9552L8.85653 1.15617ZM8.85653 20.9552L16.5562 13.2555L8.85653 20.9552ZM8.85653 20.9552L1.15692 13.2556L8.85653 20.9552Z"
                        fill="#58595B" />
                    <path
                        d="M8.85653 1.15617L8.85653 20.9552M8.85653 20.9552L16.5562 13.2555M8.85653 20.9552L1.15692 13.2556"
                        stroke="#58595B" stroke-width="2.31318" stroke-linecap="round" stroke-linejoin="round" />
                </svg>

            </a>
        </div>

    </div>
</section>

<section class="mb_100">
    <div class="container-fluid">
        <!-- <div class="search_filter_wrapper mb_80">
            <div class="search_box">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M17 17L22 22M19.5 10.75C19.5 15.5825 15.5825 19.5 10.75 19.5C5.91751 19.5 2 15.5825 2 10.75C2 5.91751 5.91751 2 10.75 2C15.5825 2 19.5 5.91751 19.5 10.75Z"
                        stroke="#666666" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>

                <input type="text" placeholder="Search by machine name, model, document type, or industry...">
            </div>

            <div class="filter_box">

                <select>
                    <option>All Categories</option>
                    <option>Category 1</option>
                    <option>Category 2</option>
                </select>

                <select>
                    <option>All Machine Types</option>
                    <option>Type 1</option>
                    <option>Type 2</option>
                </select>

                <select>
                    <option>All Industries</option>
                    <option>Industry 1</option>
                    <option>Industry 2</option>
                </select>

            </div>

        </div> -->

        <div class="download_cards_main">
            <div class="row">

                @foreach($certificate as $item)

                <div class="col-lg-4">
                    <div class="download_cards">

                        <img class="img-fluid mb_40"
                            src="{{ asset('public/front/images/pdf-img.png') }}"
                            alt="{{ $item->title }}">

                        <h4 class="title_24 text-105">
                            {{ $item->title }}
                        </h4>

                        <hr>

                        <p class="mb-0">
                            {{ $item->description }}
                        </p>

                        <a href="{{ asset('public/certificateFiles/Jinil_Brochure.pdf') }}" 
                            class="com_btn text-111"
                            download="{{ $item->file }}">

                                <span>
                                   <svg width="21" height="21" viewBox="0 0 21 21" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M10.0875 0.0940056C10.0031 0.145567 9.89531 0.25338 9.84375 0.337755C9.75 0.492443 9.75 0.59088 9.75 7.19557V13.8987L7.725 11.8784C6.60938 10.7628 5.64844 9.82994 5.59219 9.80182C5.53594 9.77369 5.37656 9.75025 5.24063 9.75025C4.78594 9.75025 4.5 10.0362 4.5 10.4909C4.5 10.6268 4.52813 10.7956 4.56563 10.8659C4.65 11.0206 10.0125 16.3737 10.1578 16.4487C10.3031 16.5237 10.7156 16.5143 10.8656 16.4346C11.0203 16.3503 16.3734 10.9878 16.4484 10.8424C16.4766 10.7862 16.5 10.6268 16.5 10.4909C16.5 10.0362 16.2141 9.75025 15.7594 9.75025C15.6234 9.75025 15.4641 9.77369 15.4078 9.80182C15.3516 9.82994 14.3906 10.7628 13.2797 11.8784L11.25 13.8987V7.19557C11.25 0.59088 11.25 0.492443 11.1563 0.337755C11.0156 0.112755 10.8047 0.000255585 10.5 0.000255585C10.3266 0.000255585 10.1906 0.0283794 10.0875 0.0940056Z"
                                        fill="#111111" />
                                    <path
                                        d="M0.3375 15.8438C0.253125 15.8953 0.145313 16.0031 0.09375 16.0875C0.0046875 16.2328 0 16.3266 0 18.0328C0 19.7297 0.0046875 19.8375 0.0984375 20.0813C0.215625 20.3953 0.501563 20.7047 0.820313 20.8594L1.05469 20.9766L10.4391 20.9906L19.8234 21L20.0859 20.9016C20.4328 20.7703 20.7703 20.4375 20.9016 20.0859C20.9953 19.8375 21 19.7344 21 18.0328C21 16.3266 20.9953 16.2328 20.9062 16.0875C20.7656 15.8625 20.5547 15.75 20.25 15.75C19.9453 15.75 19.7344 15.8625 19.5938 16.0875C19.5047 16.2328 19.5 16.3266 19.5 17.8688V19.5H10.5H1.5V17.8688C1.5 16.3266 1.49531 16.2328 1.40625 16.0875C1.35469 16.0031 1.24688 15.8953 1.1625 15.8438C0.951563 15.7172 0.548438 15.7172 0.3375 15.8438Z"
                                        fill="#111111" />
                                </svg>
                                </span>

                                <span>Download</span>

                            </a>

                    </div>
                </div>

                @endforeach

            </div>
        </div>
    </div>
</section>

@include('layouts.frontfooter')
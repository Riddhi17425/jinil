<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class checkusers
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        if(Auth::users()->role == 1 ){
            return redirect('/superAdmin');
        }
        elseif(Auth::users()->role == 2 ){
            return redirect('/admin');
        }
        elseif(Auth::users()->role == 3 ){
            return redirect('/user');
        }
    }
}

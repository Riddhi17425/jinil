@extends('admin.layouts.app')

@section('title', 'indcategory Edit')

@section('content')
<div class="container-xxl">

    <div class="row align-items-center">
        <div class="border-0 mb-4">
            <div
                class="card-header py-3 no-bg bg-transparent d-flex align-items-center px-0 justify-content-between border-bottom flex-wrap">
                <h3 class="fw-bold mb-0">indcategory Edit</h3>
                <!--<button type="submit"-->
                <!--    class="btn btn-primary py-2 px-5 text-uppercase btn-set-task w-sm-100">Save</button>-->
            </div>
        </div>
    </div> <!-- Row end  -->
    <div class="card-body">
        <form method="post" enctype="multipart/form-data" action="{{ route('indcategory.update',$indcategory->id) }}">
            @csrf
            @method('PATCH')
            <div class="row g-3 mb-3">
                <div class="col-lg-12">
                    <div class="card mb-3">
                        <div class="card-header py-3 d-flex justify-content-between bg-transparent border-bottom-0">
                            <h6 class="mb-0 fw-bold ">indcategory Details</h6>
                        </div>
                        <div class="card-body">
                            <div class="row g-3 align-items-center">
                            <div class="col-md-6">
                                <label class="form-label">indcategory</label>
                                <input type="text" id="indcategory" name="indcategory" class="form-control"
                                    value="{{ $indcategory->indcategory }}" placeholder="indcategory">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">URL</label>
                                <input type="text" id="url" name="url" class="form-control"
                                    value="{{ $indcategory->url }}" placeholder="indcategory URL">
                            </div>
                            <div class="col-md-12">
                                <label class="form-label">indcategory Description</label>
                                <textarea id="cat_description" name="cat_description" class="form-control"
                                    placeholder="indcategory Description">{{ $indcategory->cat_description }}</textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Icon Image</label>
                                <input type="file" id="icon_image" name="icon_image" class="form-control" accept=".jpg,.jpeg,.png,.webp,.svg">
                                @if ($errors->has('icon_image'))
                                    <span class="text-danger">{{ $errors->first('icon_image') }}</span>
                                @endif
                            </div>
                            @if(!empty($indcategory->icon_image))
                            <div class="col-md-6">
                                <label class="form-label d-block">Current Icon</label>
                                <img src="{{ asset('public/indcategory/icon_image/' . $indcategory->icon_image) }}" alt="Icon Image" style="width:80px;height:80px;object-fit:contain;border:1px solid #ddd;padding:4px;">
                            </div>
                            @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary py-2 px-5 text-uppercase btn-set-task w-sm-100">Save</button>
        </form>
    </div>
</div>
@endsection

@push('styles')
<!-- Summernote CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-bs4.min.css" rel="stylesheet">
<!-- Cropper CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.css">

<!--plugin css file -->
<link rel="stylesheet" href="{!! asset('public/admin_public/dist/assets/plugin/multi-select/css/multi-select.css') !!}">
<link rel="stylesheet"
    href="{!! asset('public/admin_public/dist/assets/plugin/bootstrap-tagsinput/bootstrap-tagsinput.css') !!}">
<link rel="stylesheet" href="{!! asset('public/admin_public/dist/assets/plugin/dropify/dist/css/dropify.min.css') !!}">
<link rel="stylesheet"
    href="{!! asset('public/admin_public/dist/assets/plugin/datatables/responsive.dataTables.min.css') !!}">
<link rel="stylesheet"
    href="{!! asset('public/admin_public/dist/assets/plugin/datatables/dataTables.bootstrap5.min.css') !!}">
@endpush

@push('scripts')
<!-- Summernote JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-bs4.min.js"></script>
<!-- Cropper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.js"></script>
<script src="{!! asset('public/admin_public/dist/assets/plugin/multi-select/js/jquery.multi-select.js') !!}"></script>
<script src="{!! asset('public/admin_public/dist/assets/plugin/bootstrap-tagsinput/bootstrap-tagsinput.js') !!}">
</script>
<script src="{!! asset('public/admin_public/dist/assets/bundles/dropify.bundle.js') !!}"></script>
<script src="{!! asset('public/admin_public/dist/assets/bundles/dataTables.bundle.js') !!}"></script>

@endpush

@push('custom_scripts')
<script>
$(document).ready(function() {
   
    $('#cat_description').summernote({
        placeholder: 'Enter indcategory Description here...',
        height: 300,
        toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'italic', 'underline', 'clear']],
            ['fontname', ['fontname']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['height', ['height']],
            ['insert', ['link', 'picture', 'hr']],
            ['view', ['fullscreen', 'codeview']],
            ['help', ['help']]
        ]
    });
});
</script>
@endpush
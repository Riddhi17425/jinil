@include('layouts.frontheader')

<section class="navi_page">
    <div class="container-fluid">

        <div class="navi_page_child">
            <div>
                <p class="title_24"><a href="{{ url('/')}}" class="text-585">Home</a> / Blog</p>
                <h1 class="title_60">Insights from the Surface Preparation Industry</h1>
                <p class="mb-0">Expert guidance, technical resources, and industry best practices</p>
            </div>
          
                <a href="{{ route('contact') }}"class="contact_circle">

                    <!-- circular text image -->
                    <img src="{{ asset('public/front/images/innder-header-jump.svg') }}" class="circle_text_img" alt="innder header jump">

                    <svg class="arrow_img" width="18" height="23" viewBox="0 0 18 23" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M8.85653 1.15617L8.85653 20.9552L8.85653 1.15617ZM8.85653 20.9552L16.5562 13.2555L8.85653 20.9552ZM8.85653 20.9552L1.15692 13.2556L8.85653 20.9552Z"
                            fill="#58595B" />
                        <path
                            d="M8.85653 1.15617L8.85653 20.9552M8.85653 20.9552L16.5562 13.2555M8.85653 20.9552L1.15692 13.2556"
                            stroke="#58595B" stroke-width="2.31318" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>

                </a>
        </div>

    </div>
</section>

<section class="mb_100">
    <div class="container-fluid">
        <div class="row gy-4">
            @foreach($blogs as $blog)
            <div class="col-md-4">
                <div class="insight_item">
                    <div class="insight_item_img">
                        <a href="{{ route('blogdetail', ['url' => $blog->url]) }}"><img class="w-100" src="{{ asset('public/Blogs/front_image/' . $blog->front_image) }}" alt="{{ $blog->title }}" /></a>
                    </div>
                    <div class="insight_item_content">
                        <hr>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="d-flex align-items-center gap-2">
                                @if($blog->author && $blog->author->thumbnail_image)
                                    <img src="{{ asset('public/Authors/thumbnail_image/' . $blog->author->thumbnail_image) }}"
                                        alt="{{ $blog->author->name }}"
                                        class="rounded-circle blog_author_icon">
                                @elseif($blog->author && $blog->author->main_image)
                                    <img src="{{ asset('public/Authors/main_image/' . $blog->author->main_image) }}"
                                        alt="{{ $blog->author->name }}"
                                        class="rounded-circle blog_author_icon">
                                @endif

                                @if($blog->author)
                                    <a href="{{ route('author.detail', ['slug' => $blog->author->slug]) }}"
                                    class="blog_author_name">
                                        {{ $blog->author->name }}
                                    </a>
                                @else
                                    <span class="blog_author_name">-</span>
                                @endif
                            </div>
                            <div>
                                <span class="blog_author_date">{{ $blog->date}}</span>
                            </div>
                        </div>
                        <a href="{{ route('blogdetail', ['url' => $blog->url]) }}"><h3 class="title_24">{{ $blog->title }}</h3></a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>

@include('layouts.frontfooter')